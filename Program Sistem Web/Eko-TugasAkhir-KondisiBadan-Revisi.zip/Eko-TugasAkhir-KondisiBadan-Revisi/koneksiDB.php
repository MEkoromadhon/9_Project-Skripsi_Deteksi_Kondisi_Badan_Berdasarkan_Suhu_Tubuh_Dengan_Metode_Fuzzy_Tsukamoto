<?php
	$dbhost="localhost";
	$dbuser="root";
	$dbpass="";
	$dbname="eko_tugas_akhir";

	$konek=mysqli_connect($dbhost, $dbuser, $dbpass) or die("Server tidak terhubung");
	if ($konek){
   		 mysqli_select_db($konek,$dbname);
	} else {
    	echo "Server tidak terhubung. <br>";
	}
?>