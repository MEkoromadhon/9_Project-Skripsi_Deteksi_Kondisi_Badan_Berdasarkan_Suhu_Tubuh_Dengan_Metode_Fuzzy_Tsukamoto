Web untuk menampilkan suhu dan kelembaban
