<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "eko_tugas_akhir";
	//Membuat Koneksi
	$conn = new mysqli($servername, $username, $password, $dbname);
	//Cek Koneksi
	if ($conn->connect_error) {
		die ("Gagal terhubung dengan database : " . $conn->connect_error);
	}

	$id = $_GET['id'];
	$sql = "DELETE FROM  datasuhukondisi WHERE id=$id";

	if($conn->query($sql) === TRUE){
		echo "<script> alert ('Data Suhu Tubuh dan Kondisi Badan telah berhasil di hapus . .') </script>";
		header("refresh:1; url=tabel index.php"); /*Refresh ke menu halaman tersebut*/
	} else {
		echo "Erorr: ". $sql . "<br>" . $conn->error;
	}
$conn->close();
?>
