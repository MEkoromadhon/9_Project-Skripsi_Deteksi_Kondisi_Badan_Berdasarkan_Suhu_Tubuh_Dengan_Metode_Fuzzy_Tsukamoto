<?php
    //Variabel database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eko_tugas_akhir";
    $conn = mysqli_connect("$servername", "$username", "$password","$dbname");

    // Prepare the SQL statement
    $result = mysqli_query ($conn,"INSERT INTO datasuhukondisi (suhu_tubuh, kondisi_badan) VALUES 
        ('".$_GET["Suhu-Tubuh"]."', '".$_GET["Kondisi-Badan"]."')");    
    if (!$result) 
        {
            die ('Invalid query: '.mysqli_error($conn));
        }  
?>
