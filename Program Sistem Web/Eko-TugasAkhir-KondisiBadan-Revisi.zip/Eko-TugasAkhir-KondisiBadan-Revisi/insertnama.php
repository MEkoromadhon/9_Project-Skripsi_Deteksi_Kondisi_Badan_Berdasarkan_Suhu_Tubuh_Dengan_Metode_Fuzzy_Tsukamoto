<?php
  require("koneksi.php"); // memanggil file koneksi.php untuk koneksi ke database
?>

<!DOCTYPE html>
<html>
  <head>
      <title> DETEKSI KONDISI BADAN </title>
  </head>
    <body>
      <style>
        body {background-color: #f2f2f2;} /*Untuk warna background*/
        #wntable {
          border-collapse: collapse;
          width: 50%;
        }
        #wntable td, #wntable th { /*Untuk border tabel*/
          border: 2px solid #ddd;
          padding: 7px;
        }
        #wntable tr:nth-child(even){background-color: white;} /*Untuk tabel pertama*/
        #wntable tr:hover {background-color: #ddd;}
        #wntable th {  /*Untuk tabel judul atas*/
          padding-top: 12px;
          padding-bottom: 12px;
          text-align: left;
          background-color: #00A8A9; 
          color: white;
        }
      </style>

 <div id="cards" class="cards" align="center">
  <br><br><br><br><br><br><br><br><br><br><hr><br><br><br><br> <br>
   <b style = "font-size: 30px; text-align:center; color:blue; text-shadow: 0 0 2px DodgerBlue;"> - Data Anda Telah Tersimpan - </b>
   <br><br><br><br><br><br><hr>
   <br>
<!------------------------- Program Bagian Link ------------------------> 
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "eko_tugas_akhir";
    //Membuat Koneksi
    $conn = mysqli_connect($servername, $username, $password, $database);
    //Cek Koneksi
    if(!$conn){
      echo "Not Connection to server";
    }
    
    if(isset($_GET['tambahnama'])){
       
        $Nama = $_GET['tambahnama'];
        $sql= "Select max(id) as terakhir from datasuhukondisi"; //query untuk ambil data nilai tertinggi dari kolom id karena id type datanya ineger
        // max(id) berarti mengambil nilai max dari kolom id, kalau mau ambil nilai terkecil berarti pakai min(id)
        $maxsql=mysqli_query($conn, $sql); // perintah untuk eksekusi query
        $datadb = mysqli_fetch_array($maxsql); // perintah unuk ambil data hasil query dan dimasukkan ke variabel datadb dan perintah ini hanya menampilakn 1 baris data saja
        $max=$datadb[0];//perintah untuk ambil data dari variabel datadb di kolom 1 dan memasukkan ke variabel max
        $xnama=$Nama;
        $sqlupdate= "UPDATE datasuhukondisi SET nama_lengkap = '$xnama' WHERE  id ='$max'"; //query untuk edit data dengan syarat data idnya yang sama dengan nilai di variabel max

    if(!mysqli_query($conn, $sqlupdate)){
      echo "Insert Failed";
    } else {
    mysqli_close($conn);
    header("refresh:2 url=index.html"); /*Refresh ke menu halaman tersebut*/
    }
 }        
?>
</div>
</body>
</html>