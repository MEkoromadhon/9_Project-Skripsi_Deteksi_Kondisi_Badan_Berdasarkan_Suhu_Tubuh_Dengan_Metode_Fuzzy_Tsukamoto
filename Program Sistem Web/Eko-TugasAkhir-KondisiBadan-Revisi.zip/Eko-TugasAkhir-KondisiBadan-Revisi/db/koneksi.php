<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eko_tugas_akhir";
$konek = mysqli_connect ($servername, $username, $password, $dbname); // Perintah untuk menghubungkan ke database
if (!$konek) {
    die("Connection failed: " . mysqli_connect_error());
}


?>