<?php
  require("koneksi.php"); // memanggil file koneksi.php untuk koneksi ke database
?>

<!DOCTYPE html>
<html>
  <head>
      <title> DETEKSI KONDISI BADAN </title>
  <meta http-equiv="refresh" content="10"> 
  </head>
    <body>
      <style>
        body {background-color: #f2f2f2;} /*Untuk warna background*/
        #wntable {
          border-collapse: collapse;
          width: 50%;
        }
        #wntable td, #wntable th { /*Untuk border tabel*/
          border: 2px solid #ddd;
          padding: 7px;
        }
        #wntable tr:nth-child(even){background-color: white;} /*Untuk tabel pertama*/
        #wntable tr:hover {background-color: #ddd;}
        #wntable th {  /*Untuk tabel judul atas*/
          padding-top: 12px;
          padding-bottom: 12px;
          text-align: left;
          background-color: #00A8A9; 
          color: white;
        }
      </style>

 <div id="cards" class="cards" align="center">
   <b style = "font-size: 30px; text-align:center; color:blue; text-shadow: 0 0 2px DodgerBlue;"> DATA </b><br>
   <b style = "font-size: 30px; text-align:center; color:blue; text-shadow: 0 0 2px DodgerBlue;"> SUHU TUBUH DAN KONDISI BADAN </b>
<hr color="#00A8A9" size="2">
    <form action="index.html" method="POST" name="input">
        <button style="margin-left: 1200px; width: 100px; height: 35px; cursor: pointer; box-shadow: 0 0 3px #00A8A9;"><b> Kembali </b></button>
    </form>
    <form action="tabel index.php" method="POST">
        <input name="cari" type="text" style="width: 20%; height: 19px; font-size: 15px;" autofocus="cari">
        <input style="height: 25px; box-shadow: 0 0 3px grey; cursor: pointer; " type="submit" value="Cari Id">
    </form><br>
<?php 
    include 'config2.php';
?>
<?php 
    if(isset($_POST['cari'])){
        $cari = $_POST['cari'];
    }
?>
<table id="wntable">
     <tr>
        <th>No.</th>
        <th>Id</th>
        <th>Nama Lengkap</th>
        <th>Suhu Tubuh</th>
        <th>Kondisi Badan</th>
        <th>Waktu</th>
        <th style="background-color:red;"> Hapus Data </th>
     </tr>
<?php 
$sql = mysqli_query($koneksi, "SELECT * FROM datasuhukondisi ORDER BY id DESC");
    if(isset($_POST['cari'])){
        $cari = $_POST['cari'];
        $row = mysql_query("select * from datasuhukondisi where id like '%".$cari."%'");               
    }else{
        $row = mysql_query("select * from datasuhukondisi");       
    }
    if(mysqli_num_rows($sql) == 0){ 
            echo '<tr><td colspan="14">Data tidak ada.</td></tr>'; // jika tidak ada entri di database maka tampilkan 'Data Tidak Ada.'
          }else{
    $no = 1;
    if($row===FALSE){
        die(mysql_error());
    }
    while($d = mysql_fetch_array($row)){
?>
    <tr>
        <td><b><?php echo $no++; ?>.</b></td>
        <td><?php echo $d['id']; ?></td>
        <td><?php echo $d['nama_lengkap']; ?></td>
        <td><?php echo $d['suhu_tubuh']; ?></td>
        <td><?php echo $d['kondisi_badan']; ?></td>
        <td><?php echo $d['waktu']; ?></td>
        <td><?php echo "<button style='width:70px; height:28px; background-color:red; margin-left:25px;'><b><a href='javascript:hapusData(".$d['id'].")' style='text-decoration:none; color: white;'> Hapus </a></b></button>" ?></td>
    </tr>
<?php
}} ?>
<script language="javascript" type="text/javascript">
  function hapusData(id){
    if(confirm("Apakah anda yakin akan menghapus data ini ?")){
      window.location.href = 'Delete Data Suhu & Kondisi (Admin).php?id=' + id;
    }
  }
</script>
</table>
</div>
  <br><hr color="#00A8A9" size="2">
    <h4 style = "text-align:center; color:black;"> @Tugas_Akhir 2022 - Muhammad Eko Romadhon </h4>
</body>
</html>