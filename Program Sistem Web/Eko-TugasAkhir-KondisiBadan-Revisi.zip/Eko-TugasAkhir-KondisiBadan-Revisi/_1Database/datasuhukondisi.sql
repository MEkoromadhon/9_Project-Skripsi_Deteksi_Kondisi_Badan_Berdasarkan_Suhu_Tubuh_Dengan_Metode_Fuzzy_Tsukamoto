-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2022 at 04:22 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eko_tugas_akhir`
--

-- --------------------------------------------------------

--
-- Table structure for table `datasuhukondisi`
--

CREATE TABLE IF NOT EXISTS `datasuhukondisi` (
  `id` int(6) unsigned NOT NULL,
  `suhu_tubuh` float DEFAULT NULL,
  `kondisi_badan` varchar(50) NOT NULL,
  `waktu` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nama_lengkap` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datasuhukondisi`
--

INSERT INTO `datasuhukondisi` (`id`, `suhu_tubuh`, `kondisi_badan`, `waktu`, `nama_lengkap`) VALUES
(7, 35.45, 'Dingin', '2022-04-18 08:38:01', 'Ismanto'),
(8, 37.29, 'Normal', '2022-04-18 08:39:08', 'Sri Suparni'),
(9, 35.55, 'Dingin', '2022-04-18 08:41:50', 'Mintarsih'),
(10, 37.05, 'Normal', '2022-04-18 08:43:20', 'Neti Erawati'),
(11, 36.27, 'Dingin', '2022-04-18 08:45:27', 'Saidah'),
(12, 36.05, 'Dingin', '2022-04-18 08:47:34', 'Ifandhi'),
(13, 36.31, 'Dingin', '2022-04-18 08:49:43', 'Yuli Hartatik'),
(14, 36.61, 'Normal', '2022-04-18 08:52:50', 'Desi Damayanti'),
(15, 35.11, 'Dingin', '2022-04-18 08:54:59', 'Arbaningsih'),
(16, 37.13, 'Normal', '2022-04-18 08:57:07', 'Yulianti'),
(17, 36.55, 'Normal', '2022-04-18 08:59:13', 'Siti Mutia'),
(18, 35.69, 'Dingin', '2022-04-18 09:02:19', 'Nunuk Nurhasanah'),
(19, 36.89, 'Normal', '2022-04-18 09:05:24', 'Saniah'),
(20, 37.35, 'Normal', '2022-04-18 09:07:30', 'Siti Azizah'),
(21, 36.79, 'Normal', '2022-04-18 09:09:36', 'Nia Kurniasih'),
(22, 37.71, 'Normal', '2022-04-18 09:11:42', 'Junna Nurkholil'),
(23, 35.97, 'Dingin', '2022-04-18 09:13:49', 'Rizki Fadilah'),
(24, 36.93, 'Normal', '2022-04-18 09:15:00', 'Alfath Pahlefi'),
(25, 36.89, 'Normal', '2022-04-18 09:17:06', 'Rifaldi Ramadhan'),
(26, 37.73, 'Normal', '2022-04-18 09:19:12', 'Ramdan Faudzan'),
(27, 36.57, 'Normal', '2022-04-18 09:21:19', 'Dirga Firmasyah'),
(28, 36.93, 'Normal', '2022-04-18 09:23:26', 'Rafa Aditya N'),
(29, 37.89, 'Normal', '2022-04-18 09:25:34', 'Keisha Eka Putri'),
(30, 36.91, 'Normal', '2022-04-18 09:26:40', 'Amir Surya Wijaya'),
(31, 37.01, 'Normal', '2022-04-18 09:28:46', 'Zulfikar Maulana'),
(32, 36.89, 'Normal', '2022-04-18 09:31:52', 'Nayla Putri'),
(33, 37.11, 'Normal', '2022-04-18 09:33:59', 'Mutia Rahmawati'),
(34, 37.65, 'Normal', '2022-04-18 09:35:05', 'Alviandy R'),
(35, 37.01, 'Normal', '2022-04-18 09:39:15', 'Jihan Aulia');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `datasuhukondisi`
--
ALTER TABLE `datasuhukondisi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `datasuhukondisi`
--
ALTER TABLE `datasuhukondisi`
  MODIFY `id` int(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
