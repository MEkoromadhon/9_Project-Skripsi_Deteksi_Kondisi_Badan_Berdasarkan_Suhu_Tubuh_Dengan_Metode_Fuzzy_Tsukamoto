<?php
include ("../db/get_data.php");
echo data('kondisi_badan'); // kondisi_badan = disesuaikan dengan kolom yg ada didatabase-nya (Harus sama, Perhatikan hurufnya)
?>