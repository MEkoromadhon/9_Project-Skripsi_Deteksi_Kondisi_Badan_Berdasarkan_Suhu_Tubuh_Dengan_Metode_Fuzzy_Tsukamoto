<?php
include ("../db/get_data.php");
echo data('suhu_tubuh')."°C"; // suhu = disesuaikan dgn kolom yg ada didatabase-nya (Harus sama, Perhatikan hurufnya)
?>