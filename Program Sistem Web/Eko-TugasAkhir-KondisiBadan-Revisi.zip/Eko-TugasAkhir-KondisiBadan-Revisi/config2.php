<?php 
// koneksi mysql ke php
mysql_connect("localhost","root","");
mysql_select_db("eko_tugas_akhir");
?>